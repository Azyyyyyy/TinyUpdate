﻿# TinyUpdate
![](../../assets/logo-60px.png)

## Getting Started Guide
The getting started guide will show you how to integrate TinyUpdate into a console application

## MyFirstUpdate
MyFirstUpdate will show the version that the application is currently on and then wait for an input before closing

![]() <!--Show image here-->

If you want to see the finished product then you can [download]() <!--Add Link--> a zip of the solution

## Overview
1. [Integrating](integrating.md) - How to integrate TinyUpdate into your application
2. [Packaging](packaging.md) - How to package your application files and prepare them for release
3. [Distributing](distributing.md) - How to provide updates files to your users
4. [Installing](installing.md) - This hasn't been implemented yet, come back later when that's the case!
5. [Updating](updating.md) - The process of updating your application to a newer version