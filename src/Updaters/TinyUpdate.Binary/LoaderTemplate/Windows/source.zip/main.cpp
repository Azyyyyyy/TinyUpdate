#include <windows.h>

int WinMain(HINSTANCE hinst,
            HINSTANCE hprev,
            LPSTR     cmdline,
            int       show)
{
    ShellExecute(nullptr, "open", "{APPLICATIONLOCATION}", nullptr, nullptr, SW_SHOWDEFAULT);
    return 0;
}